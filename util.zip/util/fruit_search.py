# from math import dist
import sys, os
import cv2
import numpy as np
import json
import ast
import argparse
import time

# import SLAM components
# sys.path.insert(0, "{}/slam".format(os.getcwd()))
# from slam.ekf import EKF
# from slam.robot import Robot
# import slam.aruco_detector as aruco

# import utility functions
sys.path.insert(0, "util")
from pibot import Alphabot
import measure as measure


def read_true_map(fname):
    """Read the ground truth map and output the pose of the ArUco markers and 3 types of target fruit to search

    @param fname: filename of the map
    @return:
        1) list of target fruits, e.g. ['redapple', 'greenapple', 'orange']
        2) locations of the target fruits, [[x1, y1], ..... [xn, yn]]
        3) locations of ArUco markers in order, i.e. pos[9, :] = position of the aruco10_0 marker
    """
    with open(fname, 'r') as f:
        try:
            gt_dict = json.load(f)                   
        except ValueError as e:
            with open(fname, 'r') as f:
                gt_dict = ast.literal_eval(f.readline())   
        fruit_list = []
        fruit_true_pos = []
        aruco_true_pos = np.empty([10, 2])

        # remove unique id of targets of the same type
        for key in gt_dict:
            x = np.round(gt_dict[key]['x'], 1)
            y = np.round(gt_dict[key]['y'], 1)

            if key.startswith('aruco'):
                if key.startswith('aruco10'):
                    aruco_true_pos[9][0] = x
                    aruco_true_pos[9][1] = y
                else:
                    marker_id = int(key[5])
                    aruco_true_pos[marker_id - 1][0] = x
                    aruco_true_pos[marker_id - 1][1] = y
            else:
                fruit_list.append(key[:-2])
                if len(fruit_true_pos) == 0:
                    fruit_true_pos = np.array([[x, y]])
                else:
                    fruit_true_pos = np.append(fruit_true_pos, [[x, y]], axis=0)

        return fruit_list, fruit_true_pos, aruco_true_pos


def read_search_list():
    """Read the search order of the target fruits

    @return: search order of the target fruits
    """
    search_list = []
    with open('search_list.txt', 'r') as fd:
        fruits = fd.readlines()

        for fruit in fruits:
            search_list.append(fruit.strip())

    return search_list


def print_target_fruits_pos(search_list, fruit_list, fruit_true_pos):
    """Print out the target fruits' pos in the search order

    @param search_list: search order of the fruits
    @param fruit_list: list of target fruits
    @param fruit_true_pos: positions of the target fruits
    """
    pos_in_order = []
    print("Search order:")
    n_fruit = 1
    for fruit in search_list:
        for i in range(5):
            if fruit == fruit_list[i]:
                print('{}) {} at [{}, {}]'.format(n_fruit,
                                                  fruit,
                                                  np.round(fruit_true_pos[i][0], 1),
                                                  np.round(fruit_true_pos[i][1], 1)))
                pos_in_order.append([np.round(fruit_true_pos[i][0], 1), np.round(fruit_true_pos[i][1], 1)])
        n_fruit += 1

    return n_fruit, pos_in_order

# Waypoint navigation
# the robot automatically drives to a given [x,y] coordinate
# additional improvements:
# you may use different motion model parameters for robot driving on its own or driving while pushing a fruit
# try changing to a fully automatic delivery approach: develop a path-finding algorithm that produces the waypoints
def drive_to_point(waypoint, robot_pose, wheel_vel):
    # imports camera / wheel calibration parameters 
    fileS = "calibration/param/scale.txt"
    scale = np.loadtxt(fileS, delimiter=',')
    fileB = "calibration/param/baseline.txt"
    baseline = np.loadtxt(fileB, delimiter=',')
    ####################################################
    # TODO: replace with your codes to make the robot drive to the waypoint
    # One simple strategy is to first turn on the spot facing the waypoint,
    # then drive straight to the way point

    wheel_vel = wheel_vel # tick to move the robot
    #print(type(waypoint), waypoint, type(robot_pose), robot_pose)
    d = np.array(waypoint) - np.array(robot_pose[0:2])
    # print(d, np.arctan2(d[1], d[0]), np.arctan2(d[1], d[0]) - robot_pose[2])
    drive_time = (np.sqrt(d[0]**2 + d[1]**2)) / (wheel_vel*scale) # replace with your calculation
    print("Driving for {:.2f} seconds".format(drive_time))

    return drive_time

def turn_to_point(waypoint, robot_pose, wheel_vel):
    # imports camera / wheel calibration parameters 
    fileS = "calibration/param/scale.txt"
    scale = np.loadtxt(fileS, delimiter=',')
    fileB = "calibration/param/baseline.txt"
    baseline = np.loadtxt(fileB, delimiter=',')
    ####################################################
    # TODO: replace with your codes to make the robot drive to the waypoint
    # One simple strategy is to first turn on the spot facing the waypoint,
    # then drive straight to the way point

    wheel_vel = wheel_vel # tick to move the robot

    
    angle_diff = get_angle_robot_to_goal(np.asarray(robot_pose), np.asarray(waypoint))
    print(f'angle_diff :{angle_diff}')
    turn_time = (angle_diff)/(2*wheel_vel*scale/baseline) # replace with your calculation
    print("Turning for {:.2f} seconds".format(turn_time))

    return turn_time
    # turn towards the waypoint
    # turn_time = 0.0 # replace with your calculation
    # print("Turning for {:.2f} seconds".format(turn_time))
    # ppi.set_velocity([0, 1], turning_tick=wheel_vel, time=turn_time)
    
    # # after turning, drive straight to the waypoint
    # drive_time = 0.0 # replace with your calculation
    # print("Driving for {:.2f} seconds".format(drive_time))
    # ppi.set_velocity([1, 0], tick=wheel_vel, time=drive_time)
    ####################################################

    # print("Arrived at [{}, {}]".format(waypoint[0], waypoint[1]))

def get_angle_robot_to_goal(robot_state=np.zeros(3), goal=np.zeros(3)):
        """
        Obtain from exercise/practical
        Compute angle to the goal relative to the heading of the robot.
        Angle is restricted to the [-pi, pi] interval
        :param robot_state: 3D vector (x, y, theta) representing the current state of the robot
        :param goal: 3D Cartesian coordinates of goal location
        """
        if goal.shape[0] < 3:
            goal = np.hstack((goal, np.array([0])))

        x_goal, y_goal,_ = goal
        x, y, theta = robot_state
        x_diff = x_goal - x
        y_diff = y_goal - y

        alpha = clamp_angle(np.arctan2(y_diff, x_diff) - theta)

        return alpha

def clamp_angle(rad_angle=0, min_value=-np.pi, max_value=np.pi):
        """
        Restrict angle to the range [min, max]
        :param rad_angle: angle in radians
        :param min_value: min angle value
        :param max_value: max angle value
        """

        if min_value > 0:
            min_value *= -1

        angle = (rad_angle + max_value) % (2 * np.pi) + min_value

        return angle

def get_robot_pose(operate):
    ####################################################
    # TODO: replace with your codes to estimate the pose of the robot
    # We STRONGLY RECOMMEND you to use your SLAM code from M2 here

    # update the robot pose [x,y,theta]
    
    # robot_pose = [0.0,0.0,0.0] # replace with your calculation
    # img = operate.pibot.get_image()
    # lms, operate.aruco_img = operate.aruco_det.detect_marker_positions(img)
    # operate.ekf.predict(drive_meas)
    # operate.ekf.update(lms)

    robot_pose = operate.ekf.robot.state
    robot_pose = robot_pose.flatten().tolist()
    ####################################################

    return robot_pose

def real2grid(vect):
    return [[(vec[0])*10, (vec[1])*10] for vec in vect]

def grid2real(vect):
    return [[(vec[0])*0.1, (vec[1])*0.1] for vec in vect]

def dist_to_node(robot_pose, waypoint):

    dist = np.sqrt(robot_pose[0]**2 + robot_pose[1]**2)
    angle = get_angle_robot_to_goal(np.asarray(robot_pose), np.asarray(waypoint))
    angle = angle * 180/np.pi

    return dist, angle

def drive_with_distance(distance, wheel_vel):
    # imports camera / wheel calibration parameters 
    fileS = "calibration/param/scale.txt"
    scale = np.loadtxt(fileS, delimiter=',')
    fileB = "calibration/param/baseline.txt"
    baseline = np.loadtxt(fileB, delimiter=',')
    ####################################################
    # TODO: replace with your codes to make the robot drive to the waypoint
    # One simple strategy is to first turn on the spot facing the waypoint,
    # then drive straight to the way point

    wheel_vel = wheel_vel # tick to move the robot
    #print(type(waypoint), waypoint, type(robot_pose), robot_pose)
    d = distance
    # print(d, np.arctan2(d[1], d[0]), np.arctan2(d[1], d[0]) - robot_pose[2])
    drive_time = d / (wheel_vel*scale) # replace with your calculation
    #print("Driving for {:.2f} seconds".format(drive_time))

    return drive_time

def turn_with_angle(angle, wheel_vel):
    # imports camera / wheel calibration parameters 
    fileS = "calibration/param/scale.txt"
    scale = np.loadtxt(fileS, delimiter=',')
    fileB = "calibration/param/baseline.txt"
    baseline = np.loadtxt(fileB, delimiter=',')
    ####################################################
    # TODO: replace with your codes to make the robot drive to the waypoint
    # One simple strategy is to first turn on the spot facing the waypoint,
    # then drive straight to the way point

    wheel_vel = wheel_vel # tick to move the robot

    
    angle_diff = angle
    turn_time = (angle_diff)/(2*wheel_vel*scale/baseline) # replace with your calculation
    #print("Turning for {:.2f} seconds".format(turn_time))

    return turn_time

def find_closest_goal(robot_x, robot_y, goal_x, goal_y, safe_radius):
    dists = []
    goalpoints = []

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x - safe_radius, goal_y + safe_radius])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x - safe_radius, goal_y + safe_radius])

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x - safe_radius, goal_y])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x - safe_radius, goal_y])

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x - safe_radius, goal_y - safe_radius])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x - safe_radius, goal_y - safe_radius])

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x + safe_radius, goal_y + safe_radius])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x + safe_radius, goal_y + safe_radius])

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x + safe_radius, goal_y])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x + safe_radius, goal_y])

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x + safe_radius, goal_y - safe_radius])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x + safe_radius, goal_y - safe_radius])

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x, goal_y + safe_radius])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x, goal_y + safe_radius])

    d = np.array([int(robot_x*10), int(robot_y*10)]) - np.array([goal_x, goal_y - safe_radius])
    dists.append(np.sqrt(d[0]**2 + d[1]**2))
    goalpoints.append([goal_x, goal_y - safe_radius])

    return goalpoints[np.argmin(dists)] 